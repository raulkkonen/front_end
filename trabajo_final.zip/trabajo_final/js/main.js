$(".bloque-pie li").click(function(){
	console.log("click");
	$(".bloque-pie li").removeClass("social-pie-activo");
	$(this).addClass("social-pie-activo");
})